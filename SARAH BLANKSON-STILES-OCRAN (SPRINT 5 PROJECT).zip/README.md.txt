TABLEAU PROJECT
A REVIEW OF RETURNED PRODUCTS TO SUPERSTORE: REASONS FOR RETURNS AND SUGGESTIONS

Tableau Link
https://public.tableau.com/app/profile/sarah.blankson.stiles.ocran/viz/SARAHBLANKSON-STILES-OCRANSPRINT5PROJECT/ReturnsPresentation?publish=yes

Video Presentation
https://www.loom.com/share/136d70c147764001bcb09441693ff185
