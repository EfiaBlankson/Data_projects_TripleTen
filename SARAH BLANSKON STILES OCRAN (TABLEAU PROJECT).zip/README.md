TABLEAU PROJECT

A review of the superstore’s operations for increasing its profitability to avoid bankruptcy

https://public.tableau.com/app/profile/sarah.blankson.stiles.ocran/viz/SARAHBLANKSON-STILES-OCRANTABLEAUPROJECT-SUPERSTORES/Profit_and_Loss?publish=yes
